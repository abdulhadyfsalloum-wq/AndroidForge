package com.hermes.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hermes.data.Message
import com.hermes.data.MessageStatus
import com.hermes.data.MessageType
import com.hermes.R
import android.widget.TextView
import android.widget.ImageView
import com.hermes.data.MessageType

/**
 * MessageAdapter: Handles the display logic for the RecyclerView in the Chat Activity.
 */
class MessageAdapter(private val messageList: List<Message>) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    inner class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val contentTextView: TextView = view.findViewById(R.id.tv_message_content)
        val statusIndicator: ImageView = view.findViewById(R.id.iv_status_indicator)
        // Note: The container handles alignment (start/end) based on sender logic
    }

    override fun onCreateViewHolder(view: View, layoutInflater: android.view.LayoutInflater) {
        val view = LayoutInflater.from(view.context).inflate(R.layout.item_chat_bubble, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messageList[position]

        // 1. Set Content
        holder.contentTextView.text = message.content

        // 2. Set Status Indicator
        when (message.status) {
            MessageStatus.PENDING -> {
                holder.statusIndicator.setImageResource(R.drawable.ic_default_avatar) // Placeholder
            }
            MessageStatus.SENT -> {
                // Success checkmark for Sent
                holder.statusIndicator.setImageResource(R.drawable.ic_send) 
            }
            MessageStatus.DELIVERED -> {
                // Delivered checkmark
                holder.statusIndicator.setImageResource(R.drawable.ic_checkmark) 
            }
            MessageStatus.FAILED -> {
                // Placeholder for failure state
                holder.statusIndicator.setImageResource(android.R.drawable.ic_dialog_alert) 
            }
        }
        
        // 3. Handle Alignment (Crucial for WhatsApp Look)
        val isSentByMe = message.senderId == "CURRENT_USER_ID" // Mock logic
        if (isSentByMe) {
            // Right alignment for sent messages
            // (Layout adjustment required in XML or via Constraints)
            holder.itemView.layoutParams.setMargins(0, 0, 8, 0)
        } else {
            // Left alignment for received messages
            // (Layout adjustment required in XML or via Constraints)
        }
    }

    override fun getItemCount(): Int = messageList.size
}