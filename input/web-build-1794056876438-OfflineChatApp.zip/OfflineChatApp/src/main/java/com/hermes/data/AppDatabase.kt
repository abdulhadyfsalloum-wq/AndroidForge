package com.hermes.data

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * AppDatabase: The main database instance that ties the data entities and DAOs together.
 * This database handles all local storage operations for the application.
 */
@Database(entities = [Message::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    
    /**
     * DAO accessor for all message database operations.
     */
    abstract fun messageDao(): MessageDao
}