package com.hermes.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.hermes.data.Message
import com.hermes.data.MessageRepository
import kotlinx.coroutines.launch

/**
 * ChatViewModel: Manages UI-related data for the Chat Screen.
 * It abstracts the data source complexity (DB/P2P) from the UI (Activity/Fragment).
 */
class ChatViewModel(private val repository: MessageRepository) : ViewModel() {

    /**
     * Provides a real-time stream of messages for a specific conversation.
     * This flow updates the UI instantly when a new message is saved or received.
     * @param peerId The ID of the peer (contact) to view the conversation with.
     */
    fun getChatMessages(peerId: String) = repository.getConversationFlow(peerId).asLiveData()

    /**
     * Function called by the UI when the user sends a new message.
     * This message is immediately saved to the DB and queued for P2P transmission.
     * @param senderId The ID of the current user's device.
     * @param recipientId The ID of the contact/peer.
     * @param content The message text.
     */
    fun sendMessage(senderId: String, recipientId: String, content: String) = viewModelScope.launch {
        val newMessage = Message(
            senderId = senderId,
            recipientId = recipientId,
            content = content,
            messageType = com.hermes.data.MessageType.TEXT,
            status = com.hermes.data.MessageStatus.PENDING
        )
        repository.saveMessage(newMessage)
    }

    /**
     * Triggered by the P2PManager when a connection is established.
     * This ensures all pending messages are sent out.
     */
    fun processPendingMessages() = viewModelScope.launch {
        repository.processPendingQueue()
    }
    
    // NOTE: A real implementation would also include functions to handle incoming messages
    // from the P2PManager and update the database status accordingly.
}

/**
 * ViewModel Factory to allow dependency injection (e.g., in Activities/Fragments).
 */
class ChatViewModelFactory(private val repository: MessageRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}