package com.hermes

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.hermes.data.MessageRepository
import com.hermes.ui.ChatViewModel
import com.hermes.ui.ChatViewModelFactory
import com.hermes.p2p.P2PManager
import com.hermes.data.MessageStatus

/**
 * MainActivity: The main entry point for the chat application.
 * This Activity is responsible for initializing the application components
 * and setting up the UI to react to message changes.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var repository: MessageRepository
    private lateinit var p2pManager: P2PManager
    private lateinit var viewModel: ChatViewModel

    // Unique ID for the current user's device, crucial for P2P identification
    private val CURRENT_DEVICE_ID = "User_Device_XYZ" 

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // NOTE: In a complete setup, Application context would be accessed here.
        // For this template, we simulate initialization.
        
        // 1. Get Core Services
        // We assume OfflineChatApplication has run and initialized the core dependencies
        // In a real app: val app = application as OfflineChatApplication
        // repository = app.getRepository() 
        // p2pManager = app.getP2PManager() 
        
        // Simulation of dependency injection:
        // Since we don't have the application context fully wired here, we simulate the objects:
        // TODO: Inject dependencies properly using Hilt or Koin.
        val mockRepository = MessageRepository(
            // Mocking DAO and P2PManager for compilation, needs real implementations
            // We pass nulls/placeholders until the whole structure is wired up.
            mockDao(), // Replace with actual dependency
            mockP2PManager() // Replace with actual dependency
        )
        repository = mockRepository
        p2pManager = mockP2PManager()
        
        // 2. Initialize ViewModel
        val factory = ChatViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(ChatViewModel::class.java)
        
        // 3. Setup Listeners and Logic
        setupP2PListeners()
        setupMessageObservers()

        // Simulate a message being sent upon launch for testing
        simulateInitialMessageSend()
    }
    
    private fun setupP2PListeners() {
        // Observer for peer list changes
        p2pManager.peerList.observe(this) { peerSet ->
            Log.i("MainActivity", "Peers updated. Found ${peerSet.size} devices.")
            // Update Contact List UI here
        }
    }

    private fun setupMessageObservers() {
        // Simulate observing messages for a specific peer ID
        val targetPeerId = "Device_A_UUID"
        viewModel.getChatMessages(targetPeerId).observe(this) { messages ->
            Log.d("MainActivity", "Received ${messages.size} messages for peer $targetPeerId.")
            // Update Chat UI List here
        }
    }
    
    private fun simulateInitialMessageSend() {
        // Simulate the user typing and sending a message to test the flow
        Log.i("MainActivity", "Simulating initial message send...")
        viewModel.sendMessage(CURRENT_DEVICE_ID, "Device_A_UUID", "Hello! This is a P2P test message.")
    }
    
    // MOCK implementations for compilation purposes (MUST be replaced with actual dependencies)
    private fun mockDao(): MessageDao {
        return object : MessageDao {
            override suspend fun insert(message: Message): Long = 1L
            override fun getConversation(peerId: String): Flow<List<Message>> = kotlinx.coroutines.flow.flowOf(emptyList())
            override suspend fun updateMessageStatus(messageId: Int, newStatus: MessageStatus) {}
            override suspend fun getPendingMessages(statuses: List<MessageStatus>): List<Message> = emptyList()
        }
    }
    
    private fun mockP2PManager(): P2PManager {
        return object : P2PManager(this) {
            override fun startDiscovery() { Log.d(TAG, "Mock discovery started.") }
            override fun getDiscoveredPeers(): Set<String> = setOf("Device_A_UUID")
            override fun connectToPeer(deviceId: String, config: P2PConfig): Boolean = true
            override fun disconnectPeer(deviceId: String) {}
        }
    }
}