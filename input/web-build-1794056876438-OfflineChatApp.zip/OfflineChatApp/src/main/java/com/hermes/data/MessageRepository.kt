package com.hermes.data

import com.hermes.p2p.P2PManager
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * MessageRepository: Acts as the single source of truth, managing data flow between the UI,
 * the local database (Dao), and the P2P network layer (P2PManager).
 */
class MessageRepository(
    private val messageDao: MessageDao,
    private val p2pManager: P2PManager,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    // Queue to handle messages that need to be pushed to P2P when they are pending
    private val pendingTransmissionQueue = ConcurrentLinkedQueue<Message>()

    /**
     * Saves a message and initiates the transmission process if offline.
     * @return The ID of the saved message.
     */
    suspend fun saveMessage(message: Message): Long = withContext(ioDispatcher) {
        val messageId = messageDao.insert(message)
        
        // Add to the local queue for later P2P transmission
        pendingTransmissionQueue.add(message)
        
        // NOTE: In a real application, we would trigger P2PManager.processQueue() here.
        Log.d("Repository", "Message saved with ID $messageId and queued for P2P transmission.")
        return@withContext messageId
    }

    /**
     * Retrieves the flow of messages for a specific peer, updating the UI in real-time.
     */
    fun getConversationFlow(peerId: String) = messageDao.getConversation(peerId)

    /**
     * Fetches all messages that are currently PENDING or FAILED, signaling the P2P layer.
     * This is critical for resuming transmission after app startup.
     */
    suspend fun fetchMessagesToTransmit(): List<Message> = withContext(ioDispatcher) {
        // Fetch all messages marked for transmission attempt
        messageDao.getPendingMessages(listOf(MessageStatus.PENDING, MessageStatus.FAILED))
    }

    /**
     * Updates the status of a message after a successful or failed P2P attempt.
     */
    suspend fun updateMessageDeliveryStatus(messageId: Int, status: MessageStatus) = withContext(ioDispatcher) {
        messageDao.updateMessageStatus(messageId, status)
    }
    
    /**
     * Simulates the P2P Manager processing the queue and updating statuses.
     * NOTE: This function would be called by the P2PManager when a connection is established.
     */
    suspend fun processPendingQueue() = withContext(ioDispatcher) {
        while (true) {
            val nextMessage = pendingTransmissionQueue.poll()
            if (nextMessage == null) break
            
            Log.d("Repository", "Processing next pending message: ${nextMessage.messageId}")
            
            // 1. Attempt P2P transmission using p2pManager.connectToPeer()
            // 2. If successful:
            //    updateMessageDeliveryStatus(nextMessage.messageId, MessageStatus.SENT)
            // 3. If failed:
            //    updateMessageDeliveryStatus(nextMessage.messageId, MessageStatus.FAILED)
            
            // Simulation: Assume successful delivery for this template
            updateMessageDeliveryStatus(nextMessage.messageId, MessageStatus.SENT)
        }
    }
}