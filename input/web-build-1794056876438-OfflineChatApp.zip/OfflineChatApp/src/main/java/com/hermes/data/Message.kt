package com.hermes.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

/**
 * Message Entity: Represents a single message stored in the local Room database.
 * This is the core data structure for all communications.
 */
@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true)
    val messageId: Int = 0,

    val senderId: String, // ID of the sending device/peer
    val recipientId: String, // ID of the receiving device/peer
    val content: String, // The actual message body (text, or file path for media)
    val timestamp: Long = System.currentTimeMillis(),
    val messageType: MessageType, // TEXT, IMAGE, FILE
    val status: MessageStatus = MessageStatus.PENDING // PENDING, SENT, DELIVERED, FAILED
)

/**
 * Enum for the type of content being transmitted.
 */
enum class MessageType {
    TEXT,
    IMAGE,
    FILE // For documents
}

/**
 * Enum for the delivery status of the message.
 */
enum class MessageStatus {
    PENDING,    // Queued for P2P transfer
    SENT,       // Successfully handed off to the P2P module
    DELIVERED,  // Successfully received by the recipient peer
    FAILED      // Failed to deliver (e.g., device offline)
}