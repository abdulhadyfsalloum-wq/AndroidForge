package com.hermes.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * MessageDao: Data Access Object for interacting with the local SQLite database.
 * Provides asynchronous access to the Message entities.
 */
@Dao
interface MessageDao {

    /**
     * Inserts a new message into the database.
     * @param message The message entity to save.
     * @return The row ID of the inserted message.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: Message): Long

    /**
     * Retrieves all messages for a specific chat conversation (between two peers).
     * This uses a Flow to provide real-time updates as new messages are added.
     * @param peerId The ID of the target peer.
     * @return A flow of all messages relevant to this conversation.
     */
    @Query("SELECT * FROM messages WHERE recipientId = :peerId OR senderId = :peerId ORDER BY timestamp ASC")
    fun getConversation(peerId: String): Flow<List<Message>>

    /**
     * Updates the status of a specific message (e.g., from PENDING to DELIVERED).
     * @param messageId The ID of the message to update.
     * @param newStatus The new status enum.
     */
    @Query("UPDATE messages SET status = :newStatus WHERE messageId = :messageId")
    suspend fun updateMessageStatus(messageId: Int, newStatus: MessageStatus)

    /**
     * Retrieves all messages that are PENDING or FAILED to be processed by the P2P module.
     * These are the messages the P2PManager needs to pick up for transmission.
     * @return A list of pending messages.
     */
    @Query("SELECT * FROM messages WHERE status IN (:statuses) ORDER BY timestamp ASC")
    suspend fun getPendingMessages(statuses: List<MessageStatus>): List<Message>
}