package com.hermes

import android.app.Application
import androidx.room.Room
import com.hermes.data.AppDatabase
import com.hermes.data.MessageDao
import com.hermes.data.MessageRepository
import com.hermes.p2p.P2PManager

/**
 * OfflineChatApplication: Custom Application class that initializes and manages 
 * application-wide components like the Database and the P2P Manager.
 */
class OfflineChatApplication : Application() {

    private var database: AppDatabase? = null
    private var messageRepository: MessageRepository? = null
    private var p2pManager: P2PManager? = null

    override fun onCreate() {
        super.onCreate()
        
        // 1. Initialize Database
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "offline_chat_db"
        ).build()

        // 2. Initialize DAO and Repository
        val messageDao = database!!.messageDao()
        messageRepository = MessageRepository(messageDao, P2PManager(applicationContext))

        // 3. Initialize P2P Manager (The core offline connectivity handler)
        p2pManager = P2PManager(applicationContext)

        Log.d("Application", "Application components initialized successfully: DB, Repository, P2PManager.")
        
        // Start discovery immediately upon app launch
        p2pManager!!.startDiscovery()
    }

    // Public accessors (used by ViewModels)
    fun getRepository(): MessageRepository {
        return messageRepository ?: throw IllegalStateException("Repository not initialized.")
    }

    fun getP2PManager(): P2PManager {
        return p2pManager ?: throw IllegalStateException("P2PManager not initialized.")
    }
}